<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Quick PC Solutions - Troubleshoot Guides</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css" />
  <link rel="stylesheet" href="/quick-pc1/css/guides.css" />
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo" />
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li>
            <button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button>
          </li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
  <section class="hero">
  <div class="hero-content">
    <h2>Tech Troubleshooting Guides</h2>
    <p>Encountering issues with your technology? Check out our detailed troubleshooting guides to help you resolve problems quickly.</p>
    
  </div>
</section>


  <section id="troubleshoot-guides" class="guide-list">
  <article class="guide-card">
    <img src="/quick-pc1/images/bluescreen.avif" alt="Blue Screen Error">
    <div class="guide-content">
      <h3><a href="blue-screen.php">How to Fix Blue Screen Errors</a></h3>
      <p>Learn how to diagnose and fix common blue screen errors on Windows.</p>
    </div>
  </article>

  <article class="guide-card">
    <img src="/quick-pc1/images/how-to-fix-slow-computer.jpeg" alt="Slow PC">
    <div class="guide-content">
      <h3><a href="slow-pc.php">Speed Up a Slow PC</a></h3>
      <p>Optimize your computer performance with these troubleshooting tips.</p>
    </div>
  </article>

  <article class="guide-card">
    <img src="/quick-pc1/images/wifirouters-2048px-3572.jpg" alt="No WiFi Connection">
    <div class="guide-content">
      <h3><a href="guide-3.php">Fix No WiFi Connection Issues</a></h3>
      <p>Step-by-step solutions to resolve WiFi connectivity problems.</p>
    </div>
  </article>

  <article class="guide-card">
  <img src="/quick-pc1/images/driver.png" alt="Driver Conflicts">
  <div class="guide-content">
    <h3><a href="Driver-conflicts.php">How to Resolve Driver Conflicts</a></h3>
    <p>Step-by-step solutions to fix common driver conflicts causing system instability and device malfunctions.</p>
  </div>
</article>

  <article class="guide-card">
    <img src="/quick-pc1/images/heating.webp" alt="Overheating PC">
    <div class="guide-content">
      <h3><a href="guide-overheating.php">Fix Overheating Issues</a></h3>
      <p>Learn how to cool down your PC and prevent thermal damage.</p>
    </div>
  </article>

  <article class="guide-card">
    <img src="/quick-pc1/images/hard-disk.png" alt="Hard Drive Failure">
    <div class="guide-content">
      <h3><a href="guide-hard-drive.php">Diagnose Hard Drive Failures</a></h3>
      <p>Detect early signs of hard drive failure and recover data.</p>
    </div>
  </article>

  <article class="guide-card">
    <img src="/quick-pc1/images/ram.jpg" alt="RAM Problems">
    <div class="guide-content">
      <h3><a href="guide-ram.php">Fix RAM (Memory) Issues</a></h3>
      <p>Find and fix faulty memory that's causing crashes or lag.</p>
    </div>
  </article>

  <article class="guide-card">
    <img src="/quick-pc1/images/psu.jpg" alt="Power Supply Unit">
    <div class="guide-content">
      <h3><a href="guide-psu.php">Troubleshoot PSU Problems</a></h3>
      <p>Learn how to spot and replace a failing power supply.</p>
    </div>
  </article>

  <article class="guide-card">
    <img src="/quick-pc1/images/gpu.jpg" alt="Graphics Card Issues">
    <div class="guide-content">
      <h3><a href="guide-gpu.php">Fix Graphics Card Problems</a></h3>
      <p>Resolve screen glitches and crashes related to your GPU.</p>
    </div>
  </article>

  <article class="guide-card">
    <img src="/quick-pc1/images/MB.jpg" alt="Motherboard Issues">
    <div class="guide-content">
      <h3><a href="guide-motherboard.php">Diagnose Motherboard Issues</a></h3>
      <p>Identify common signs of motherboard failure and how to fix them.</p>
    </div>
  </article>

  <article class="guide-card">
    <img src="/quick-pc1/images/cpu.jpg" alt="CPU Problems">
    <div class="guide-content">
      <h3><a href="guide-cpu.php">Fix CPU-Related Errors</a></h3>
      <p>Detect CPU issues and ensure proper cooling and installation.</p>
    </div>
  </article>

  <article class="guide-card">
    <img src="/quick-pc1/images/cables.jpg" alt="Loose or Damaged Cables">
    <div class="guide-content">
      <h3><a href="guide-cables.php">Check and Replace Loose Cables</a></h3>
      <p>Simple fixes for power and connection issues caused by bad cables.</p>
    </div>
  </article>

  <article class="guide-card">
    <img src="/quick-pc1/images/cooling2.jpg" alt="Cooling System Failure">
    <div class="guide-content">
      <h3><a href="guide-cooling.php">Fix PC Cooling System Problems</a></h3>
      <p>Prevent overheating by maintaining fans and applying thermal paste.</p>
    </div>
  </article>

  <article class="guide-card">
  <img src="/quick-pc1/images/app-crash.webp" alt="Frequent App Crashes">
  <div class="guide-content">
    <h3><a href="app-crashes.php">How to Fix Frequent App Crashes</a></h3>
    <p>Step-by-step solutions to resolve frequent app crashes and improve stability.</p>
  </div>
</article>

<article class="guide-card">
  <img src="/quick-pc1/images/software-compatibility.png" alt="Software Compatibility">
  <div class="guide-content">
    <h3><a href="software-compatibility.php">How to Fix Software Compatibility Issues</a></h3>
    <p>Step-by-step solutions to resolve software compatibility problems and ensure your software runs smoothly.</p>
  </div>
</article>

<article class="guide-card">
  <img src="/quick-pc1/images/malware-removal.jpg" alt="Malware and Virus Infections">
  <div class="guide-content">
    <h3><a href="malware-removal.php">How to Remove Malware and Viruses</a></h3>
    <p>Step-by-step solutions to identify and remove malware and virus infections from your system.</p>
  </div>
</article>

  <article class="guide-card">
  <img src="/quick-pc1/images/win-error.png" alt="Windows Update Errors">
  <div class="guide-content">
    <h3><a href="windows-update-errors.php">How to Fix Windows Update Errors</a></h3>
    <p>Step-by-step solutions to resolve Windows update issues and ensure a smooth update process.</p>
  </div>
</article>

<article class="guide-card">
  <img src="/quick-pc1/images/system-file-repair.jpg" alt="Corrupted System Files">
  <div class="guide-content">
    <h3><a href="system-file-repair.php">How to Repair Corrupted System Files</a></h3>
    <p>Step-by-step solutions to repair corrupted system files and improve system stability.</p>
  </div>
</article>

<article class="guide-card">
  <img src="/quick-pc1/images/file-explorer-fix.png" alt="File Explorer Not Responding">
  <div class="guide-content">
    <h3><a href="file-explorer-fix.php">How to Fix File Explorer Not Responding</a></h3>
    <p>Step-by-step solutions to fix File Explorer not responding and improve system performance.</p>
  </div>
</article>

<article class="guide-card">
  <img src="/quick-pc1/images/windows-license-issues.jpeg" alt="Windows Activation or License Issues">
  <div class="guide-content">
    <h3><a href="/quick-pc1/guides/windows.php">Windows Activation or License Issues</a></h3>
    <p>Learn how to troubleshoot and fix Windows activation or license issues to ensure your system works seamlessly.</p>
  </div>
</article>

<article class="guide-card">
  <img src="/quick-pc1/images/BootFailure.jpg" alt="System Boot Failure">
  <div class="guide-content">
    <h3><a href="/quick-pc1/guides/system-boot-failure.php">System Boot Failure</a></h3>
    <p>Learn how to diagnose and fix common causes of system boot failure and get your PC running smoothly again.</p>
  </div>
</article>

<article class="guide-card">
  <img src="/quick-pc1/images/laptop-battery.jpg" alt="Laptop Battery Failure">
  <div class="guide-content">
    <h3><a href="/quick-pc1/guides/laptop-battery.php">Laptop Battery Failure</a></h3>
    <p>Learn how to identify the causes of laptop battery failure and what steps to take to fix or prevent it from happening.</p>
  </div>
</article>


</section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <!-- Scripts -->
  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
