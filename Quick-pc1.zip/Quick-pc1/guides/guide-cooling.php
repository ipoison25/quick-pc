<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PC Blog - Fix PC Cooling System Problems</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css">
  <link rel="stylesheet" href="/quick-pc1/css/guides.css">
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css">
  <style>
    .guide-article p,
    .guide-article li {
      text-align: justify;
    }
  </style>
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo">
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="guide-article">
      <h2>Fix PC Cooling System Problems</h2>
      <img src="/quick-pc1/images/cooling2.jpg" alt="PC Cooling Solutions">

      <p>An efficient cooling system is essential to keep your PC running at safe temperatures. Overheating can lead to performance throttling, crashes, and even hardware damage. Here's how to troubleshoot cooling issues and upgrade your system for optimal airflow.</p>

      <h3>Common Cooling Issues and Symptoms</h3>
      <ul>
        <li>System shuts down or reboots randomly under load</li>
        <li>CPU or GPU temperatures exceed 85°C</li>
        <li>Fans are loud, not spinning, or constantly running at max speed</li>
        <li>Thermal throttling causes low performance in games or apps</li>
      </ul>

      <h3>How to Fix Cooling Problems</h3>
      <ol>
        <li><strong>Clean the PC:</strong> Dust buildup on fans, heatsinks, and filters restricts airflow. Use compressed air to clean regularly.</li>
        <li><strong>Reapply thermal paste:</strong> Old or improperly applied paste between CPU and cooler can cause heat transfer issues.</li>
        <li><strong>Check fan connections:</strong> Ensure all fans are plugged into the correct headers and spinning freely.</li>
        <li><strong>Improve cable management:</strong> Use zip ties to organize cables and improve air circulation inside the case.</li>
        <li><strong>Reposition fans:</strong> Make sure fans are positioned for proper intake (front/bottom) and exhaust (rear/top).</li>
      </ol>

      <h3>Best Cooling Solutions for PCs</h3>
      <ul>
        <li><strong>Air Cooling:</strong> Reliable and budget-friendly. Popular choices include Noctua NH-U12S and Cooler Master Hyper 212.</li>
        <li><strong>Liquid Cooling (AIO):</strong> Quieter and more efficient cooling for high-end CPUs. Consider options like Corsair H100i or NZXT Kraken.</li>
        <li><strong>Case Fans:</strong> Add high-quality fans to improve airflow. Choose trusted brands like Arctic, Be Quiet, or Noctua.</li>
        <li><strong>Fan Controllers:</strong> Adjust fan speeds manually or automatically to balance performance and noise.</li>
        <li><strong>Laptop Cooling Pads:</strong> For laptops, external pads with built-in fans can lower surface and CPU temperatures.</li>
      </ul>

      <h3>Monitoring Tools</h3>
      <ul>
        <li><strong>HWMonitor</strong> – View real-time temperatures and voltages</li>
        <li><strong>MSI Afterburner</strong> – Monitor and control GPU temps and fan speeds</li>
        <li><strong>SpeedFan</strong> – Customize fan curves for CPU/case fans (if supported)</li>
      </ul>

      <h3>Need Help Choosing a Cooling Upgrade?</h3>
      <p>Not sure if you need better cooling or a new fan setup? <a href="/quick-pc1/contact_us.php">Contact our support team</a> and we’ll help you build a quiet, cool PC.</p>
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message...">
      <button id="send-btn">Send</button>
    </div>
  </div>

  <!-- JavaScript -->
  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
