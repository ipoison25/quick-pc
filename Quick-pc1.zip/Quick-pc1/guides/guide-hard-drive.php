<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Diagnose Hard Drive Failures</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css" />
  <link rel="stylesheet" href="/quick-pc1/css/guides.css" />
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />
  <style>
    .guide-article p, .guide-article li { text-align: justify; }
  </style>
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo" />
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="guide-article">
      <h2>Diagnose Hard Drive Failures</h2>
      <img src="/quick-pc1/images/hard-disk.png" alt="Diagnosing Hard Drive" />

      <p>A failing hard drive can lead to data loss, system crashes, or complete PC failure. Knowing how to detect hard drive issues early can help you save your data and avoid a full system breakdown.</p>

      <h3>Common Signs of Hard Drive Failure</h3>
      <ul>
        <li>Clicking, grinding, or beeping noises from the drive</li>
        <li>Frequent system freezes or crashes</li>
        <li>Files take unusually long to open or disappear entirely</li>
        <li>System displays “No boot device found” or “Disk read error”</li>
        <li>Bad sectors reported during scans</li>
      </ul>

      <h3>How to Test Your Hard Drive</h3>
      <p>Use built-in and third-party tools to check the health of your HDD:</p>
      <ul>
        <li><strong>Windows CHKDSK:</strong> Open Command Prompt as admin and run:
          <pre>chkdsk C: /f /r</pre>
          This checks and attempts to repair file system errors and bad sectors.
        </li>
        <li><strong>CrystalDiskInfo:</strong> A free utility that shows SMART (Self-Monitoring, Analysis and Reporting Technology) health data for your drive.</li>
        <li><strong>Manufacturer tools:</strong> Most brands (like Seagate, WD) offer diagnostic software on their websites.</li>
      </ul>

      <h3>What to Do If Your Drive Is Failing</h3>
      <ol>
        <li><strong>Back up your data immediately.</strong> Use cloud storage or an external drive.</li>
        <li>Try cloning the drive using tools like Macrium Reflect or Clonezilla if it's still accessible.</li>
        <li>Replace the drive with a new HDD or SSD if SMART data shows failure.</li>
      </ol>

      <h3>Tip</h3>
      <p>Always back up important files regularly. Consider using an SSD for your main system drive to improve reliability and speed.</p>

      <h3>Need Assistance?</h3>
      <p>If you're unsure whether your drive is dying, <a href="/quick-pc1/contact_us.php">contact our team</a> for a full analysis and upgrade recommendations.</p>
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
