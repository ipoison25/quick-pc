<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>PC Blog - Fix Cable Connection Issues</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css" />
  <link rel="stylesheet" href="/quick-pc1/css/guides.css" />
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />
  <style>
    .guide-article p,
    .guide-article li {
      text-align: justify;
    }
  </style>
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo" />
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="guide-article">
      <h2>Fixing Loose or Damaged Cable Issues</h2>
      <img src="/quick-pc1/images/cables.jpg" alt="PC Cables" style="width: 600px; display: block; margin: 0 auto;" />

      <p>Cables play a crucial role in powering your components and enabling communication between hardware. Faulty or loose cables are one of the simplest but most overlooked causes of computer issues.</p>

      <h3>Common Signs of Cable Issues</h3>
      <ul>
        <li>No power or random shutdowns</li>
        <li>Monitor not displaying anything</li>
        <li>Peripherals disconnect randomly</li>
        <li>Slow data transfer or charging issues</li>
      </ul>

      <h3>Steps to Fix Cable Problems</h3>
      <ol>
        <li><strong>Power Down First:</strong> Always turn off and unplug your PC before checking internal cables.</li>
        <li><strong>Check Power Supply Cables:</strong> Ensure the 24-pin motherboard connector, CPU 8-pin, and GPU power cables are fully seated.</li>
        <li><strong>Inspect SATA and Data Cables:</strong> Loose SATA cables can cause drives not to show up or crash.</li>
        <li><strong>Check Monitor and Peripheral Cables:</strong> Inspect for bent pins, fraying, or physical damage.</li>
        <li><strong>Try New Cables:</strong> Test with known-good cables to rule out defects.</li>
        <li><strong>Organize Cables:</strong> Use zip ties or velcro to avoid strain and improve airflow.</li>
      </ol>

      <h3>When to Replace Cables</h3>
      <p>If a cable shows visible damage, exposed wires, intermittent signal, or gets hot — replace it. Using faulty power cables may cause hardware damage over time.</p>

      <h3>Need More Help?</h3>
      <p>Not sure what cables you're dealing with? <a href="/quick-pc1/contact_us.php">Contact our team</a> for hands-on guidance or part recommendations.</p>
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
