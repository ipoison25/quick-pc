<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Why Is My PC Lagging?</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css" />
  <link rel="stylesheet" href="/quick-pc1/css/guides.css" />
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />
  <style>
    .guide-article p,
    .guide-article li {
      text-align: justify;
    }
  </style>
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo" />
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="guide-article">
      <h2>Why Is My PC Lagging?</h2>
      <img src="/quick-pc1/images/how-to-fix-slow-computer.jpeg" alt="Slow PC Image" />

      <p>Your computer—whether it’s a desktop, laptop, or other form factor—should feel like a fast and fluid tool. If it constantly freezes or slows down, performance issues may be the culprit.</p>

      <h2>How to Fix a Slow Computer</h2>
      <p>There are many reasons your PC might be running slowly. But three main components typically affect speed:</p>
      <ul>
        <li><strong>CPU:</strong> The processor—measured in GHz—runs everything.</li>
        <li><strong>RAM:</strong> The more GBs and speed, the smoother multitasking will be.</li>
        <li><strong>Disk Drive:</strong> A full or slow drive causes lag.</li>
      </ul>

      <p>If you're maxing these resources out, your system may freeze or crash.</p>

      <h3>Restart Your PC</h3>
      <p>Restarting clears RAM and ends background processes. It’s a quick and easy fix for many slowdowns.</p>

      <h3>Check Task Manager</h3>
      <p>Open Task Manager → Performance tab → Review CPU, RAM, and disk usage. If above 80% for long periods, you may need upgrades.</p>
      <p><strong>Tip:</strong> Close unused apps for a quick speed boost.</p>

      <h3>Disable Startup Programs</h3>
      <p>Go to <strong>Settings > Apps > Startup</strong> and turn off unneeded programs that slow down boot time.</p>

      <h3>Free Up Disk Space</h3>
      <p>Remove old files, use cleanup tools, and consider moving files to external storage or the cloud.</p>

      <h3>Pause OneDrive Sync</h3>
      <p>Syncing uses resources. Temporarily pause it from the taskbar OneDrive icon.</p>

      <h3>Scan for Malware</h3>
      <p>Run Windows Security or a trusted antivirus to check for malicious apps hogging system resources.</p>

      <h3>Add More RAM</h3>
      <p>If usage is above 80%, upgrading RAM can help a lot—especially for multitasking or gaming.</p>

      <h3>Upgrade to an SSD</h3>
      <p>SSDs are faster than HDDs. They improve boot time, app load speed, and overall system responsiveness.</p>

      <h3>Keep Drives Clean</h3>
      <p>HDDs need 10–15% free space, SSDs should have 25–30% for optimal operation.</p>

      <h3>Need Help?</h3>
      <p>Still stuck? <a href="/quick-pc1/contact_us.php">Contact our support team</a> for personal advice.</p>
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">Chat with us <span class="minimize-icon" id="minimize-chat">–</span></div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
