<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Troubleshoot PSU (Power Supply Unit) Problems</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css" />
  <link rel="stylesheet" href="/quick-pc1/css/guides.css" />
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />
  <style>
    .guide-article p, .guide-article li { text-align: justify; }
  </style>
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo" />
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="guide-article">
      <h2>Troubleshoot PSU (Power Supply Unit) Problems</h2>
      <img src="/quick-pc1/images/psu.jpg" alt="Power Supply Troubleshooting" width="800" />

      <p>The Power Supply Unit (PSU) is one of the most important components in your PC. If it's faulty or underpowered, your computer might not turn on, restart unexpectedly, or exhibit other strange behavior. Here’s how to identify and troubleshoot PSU issues.</p>

      <h3>Common Symptoms of PSU Failure</h3>
      <ul>
        <li>PC won't turn on or randomly shuts off</li>
        <li>Fans spin briefly but system doesn't boot</li>
        <li>Visible sparks, smoke, or burning smell from the PSU</li>
        <li>Unstable power leading to random crashes or reboots</li>
        <li>No lights or signs of power even with a good power cable</li>
      </ul>

      <h3>Steps to Diagnose PSU Problems</h3>
      <ol>
        <li><strong>Check the power cable:</strong> Ensure the cable is plugged in securely and test it with another device.</li>
        <li><strong>Test another wall outlet:</strong> Rule out a bad socket by trying another outlet.</li>
        <li><strong>Use the paperclip test:</strong> Jump-start the PSU by bridging the green wire to a black wire on the 24-pin connector to check if the fan spins (do this carefully).</li>
        <li><strong>Test with another PSU:</strong> If possible, use a known working PSU to rule out other hardware.</li>
        <li><strong>Use a PSU tester:</strong> These inexpensive tools can quickly tell if a PSU is operating correctly.</li>
      </ol>

      <h3>What Causes PSU Issues?</h3>
      <ul>
        <li>Power surges or poor-quality wall outlets</li>
        <li>Dust buildup inside the PSU casing</li>
        <li>Overheating due to poor airflow or fan failure</li>
        <li>Running high-performance components on a weak PSU</li>
      </ul>

      <h3>How to Prevent PSU Problems</h3>
      <ul>
        <li>Use a surge protector or UPS (Uninterruptible Power Supply)</li>
        <li>Buy a quality PSU from trusted brands (e.g. Corsair, EVGA, Seasonic)</li>
        <li>Clean your PC regularly to prevent overheating and dust buildup</li>
        <li>Ensure the PSU has enough wattage to support your hardware</li>
      </ul>

      <h3>Need Help Choosing a PSU?</h3>
      <p>If you're unsure whether your PSU is the issue or need help selecting a replacement, <a href="/quick-pc1/contact_us.php">contact our support team</a> for guidance and recommendations.</p>
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <!-- Scripts -->
  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions | All Rights Reserved</p>
  </footer>
</body>
</html>
