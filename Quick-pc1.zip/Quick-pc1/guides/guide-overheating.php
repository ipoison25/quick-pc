<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Fix Overheating Issues on Your PC</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css" />
  <link rel="stylesheet" href="/quick-pc1/css/guides.css" />
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />
  <style>
    .guide-article p,
    .guide-article li {
      text-align: justify;
    }
  </style>
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo" />
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="guide-article">
      <h2>Fix Overheating Issues on Your PC</h2>
      <img src="/quick-pc1/images/heating.webp" alt="Overheating PC" width="1000" />

      <p>Overheating can significantly affect your computer's performance and longevity. High temperatures may lead to thermal throttling, system crashes, or even hardware damage if not addressed quickly. This guide explains the common causes of overheating and how to resolve them.</p>

      <h3>What Causes a PC to Overheat?</h3>
      <ul>
        <li>Poor ventilation or airflow inside the case</li>
        <li>Dust buildup blocking fans or vents</li>
        <li>High ambient room temperature</li>
        <li>Faulty or failing cooling fans</li>
        <li>Heavy multitasking or gaming for extended periods</li>
        <li>Old thermal paste between CPU/GPU and heat sink</li>
      </ul>

      <h3>How to Fix and Prevent Overheating</h3>
      <ol>
        <li><strong>Clean Your PC:</strong> Use compressed air to remove dust from fans, heat sinks, vents, and inside the case. This improves airflow and cooling.</li>
        <li><strong>Improve Ventilation:</strong> Keep your PC in an open, well-ventilated area. Avoid placing it near heat sources or inside enclosed cabinets.</li>
        <li><strong>Use Cooling Pads or Stands:</strong> For laptops, invest in a cooling pad to provide additional airflow underneath the device.</li>
        <li><strong>Check Fans and Replace if Needed:</strong> Make sure all case, CPU, and GPU fans are spinning properly. Replace any that are noisy, slow, or dead.</li>
        <li><strong>Apply New Thermal Paste:</strong> If your CPU or GPU is old, consider removing the cooler, cleaning off the old paste, and applying a new high-quality thermal compound.</li>
        <li><strong>Monitor Temperatures:</strong> Use software like HWMonitor, Core Temp, or MSI Afterburner to track temperatures in real-time.</li>
        <li><strong>Close Intensive Apps:</strong> Shut down heavy programs when not in use. Background processes like rendering, gaming, or virtual machines increase CPU/GPU loads.</li>
        <li><strong>Underclock or Limit Performance:</strong> Reduce power settings in BIOS or Windows power plan if needed. This can decrease heat output.</li>
      </ol>

      <h3>When to Seek Professional Help</h3>
      <p>If you've tried the above and your PC continues to overheat or shuts down frequently, it may be time to consult a technician. Persistent overheating could signal failing components like the GPU, CPU, or power supply.</p>

      <h3>Need More Help?</h3>
      <p>Still running hot? <a href="/quick-pc1/contact_us.php">Contact our support team</a> for advanced diagnosis and hardware advice.</p>
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>

</body>
</html>
