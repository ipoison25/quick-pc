<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>QUICK PC SOLUTIONS - How to Fix Blue Screen Errors</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css" />
  <link rel="stylesheet" href="/quick-pc1/css/guides.css" />
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo" />
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="guide-article">
      <h2>What Causes the Blue Screen of Death?</h2>
      <img src="/quick-pc1/images/bluescreen.avif" alt="Blue Screen Error" />
      <p>
        The Blue Screen of Death (BSOD) is a critical system error that forces your PC to shut down to prevent damage. It usually happens when:
      </p>
      <ul>
        <li><strong>Hardware issues</strong> occur (like faulty RAM or a failing hard drive).</li>
        <li><strong>Driver conflicts</strong> happen between your hardware and Windows.</li>
        <li><strong>Software bugs or corrupted system files</strong> crash the system.</li>
        <li><strong>Overheating</strong> or <strong>power supply problems</strong> trigger automatic shutdown.</li>
        <li><strong>Malware or viruses</strong> damage core Windows processes.</li>
      </ul>

      <h2>How to Fix a Blue Screen Error</h2>
      <ol>
        <li><strong>Note the Stop Code:</strong> Look for error codes like <code>CRITICAL_PROCESS_DIED</code>.</li>
        <li><strong>Restart in Safe Mode:</strong> If BSOD disappears in Safe Mode, the issue is likely software/driver related.</li>
        <li><strong>Uninstall Recent Programs:</strong> Remove anything installed just before the issue started.</li>
        <li><strong>Run System File Checker:</strong> Use:
          <pre>sfc /scannow</pre>
        </li>
        <li><strong>Check for Hardware Problems:</strong> Run memory diagnostics and use <code>chkdsk /f</code>.</li>
        <li><strong>Update or Roll Back Drivers:</strong> In Device Manager.</li>
        <li><strong>Scan for Malware:</strong> With Windows Defender or trusted antivirus.</li>
        <li><strong>Use System Restore or Reset:</strong> If nothing else works.</li>
      </ol>

      <h3>Need More Help?</h3>
      <p>Contact our support <a href="/quick-pc1/contact_us.php">here</a>.</p>
    </section>

    
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <!-- Scripts -->
  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
