<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Fix RAM (Memory) Issues</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css">
  <link rel="stylesheet" href="/quick-pc1/css/guides.css">
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css">
  <style>
    .guide-article p,
    .guide-article li {
      text-align: justify;
    }
  </style>
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo">
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="guide-article">
      <h2>Fix RAM (Memory) Issues</h2>
      <img src="/quick-pc1/images/ram.jpg" alt="RAM Troubleshooting" />

      <p>Faulty or failing RAM can cause your computer to crash, freeze, or run frustratingly slow. RAM is essential for running applications and multitasking, so it's important to know when it’s causing problems and how to fix it.</p>

      <h3>Symptoms of Bad RAM</h3>
      <ul>
        <li>Frequent crashes or Blue Screen errors (BSOD)</li>
        <li>Programs randomly close or fail to start</li>
        <li>System fails to boot or shows memory-related error beeps</li>
        <li>Sluggish performance even with light tasks</li>
      </ul>

      <h3>How to Test Your RAM</h3>
      <ol>
        <li>Use the built-in Windows Memory Diagnostic Tool:
          <ul>
            <li>Search “Windows Memory Diagnostic” in the Start Menu</li>
            <li>Click "Restart now and check for problems"</li>
          </ul>
        </li>
        <li>Use third-party tools like MemTest86 for more advanced testing</li>
      </ol>

      <h3>Fixing RAM Problems</h3>
      <ul>
        <li><strong>Reseat the RAM:</strong> Power off your PC, open the case, and firmly reinsert the RAM modules</li>
        <li><strong>Clean the contacts:</strong> Use compressed air or a soft cloth to clean dust or corrosion</li>
        <li><strong>Swap and test sticks:</strong> Try each RAM stick one at a time to isolate the faulty module</li>
        <li><strong>Check compatibility:</strong> If you recently upgraded, ensure the RAM matches your motherboard specs</li>
      </ul>

      <h3>When to Replace RAM</h3>
      <p>If errors persist after testing and reseating, it's likely time to replace the faulty RAM. Always use a compatible module and install in pairs for optimal performance.</p>

      <h3>Need More Help?</h3>
      <p>Not sure if your RAM is the issue? <a href="/quick-pc1/contact_us.php">Contact our support team</a> for advice and diagnosis.</p>
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <!-- Scripts -->
  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
