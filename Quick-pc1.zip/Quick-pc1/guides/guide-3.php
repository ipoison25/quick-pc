<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>PC Blog - Fix No WiFi Connection Issues</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css">
  <link rel="stylesheet" href="/quick-pc1/css/guides.css">
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css">
  <style>
    .guide-article p,
    .guide-article li {
      text-align: justify;
    }
  </style>
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo">
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="guide-article">
      <h2>Fix No WiFi Connection Issues</h2>
      <img src="/quick-pc1/images/wifirouters-2048px-3572.jpg" alt="No WiFi Connection" style="width:100%; max-width:1000px; height:auto;">

      <p>Having no WiFi connection can be frustrating. Whether your device can’t detect the network, won’t connect, or keeps dropping the connection, this guide will walk you through the steps to fix the problem.</p>

      <h3>1. Restart Your Devices</h3>
      <p>Turn off your computer, router, and modem. Wait about 30 seconds, then power them back on. This often resolves temporary glitches.</p>

      <h3>2. Check WiFi Is Enabled</h3>
      <p>Ensure WiFi is turned on in your computer’s settings and that Airplane Mode is disabled.</p>

      <h3>3. Forget and Reconnect to Network</h3>
      <p>Remove the saved network profile and connect again. This resets the authentication and IP address.</p>

      <h3>4. Run Windows Troubleshooter</h3>
      <p>Go to <strong>Settings > Network & Internet > Status</strong> and click “Network troubleshooter.” Follow the prompts to detect and resolve issues automatically.</p>

      <h3>5. Update Network Drivers</h3>
      <p>Outdated or corrupt drivers can cause WiFi problems. In Device Manager, right-click your wireless adapter and choose “Update driver.”</p>

      <h3>6. Reset TCP/IP Stack</h3>
      <p>Open Command Prompt as Administrator and run the following commands:</p>
      <pre>
netsh winsock reset
netsh int ip reset
ipconfig /release
ipconfig /renew
ipconfig /flushdns
      </pre>

      <h3>7. Disable Security Software Temporarily</h3>
      <p>Sometimes antivirus or firewall settings can interfere with WiFi. Try disabling them briefly to test connectivity.</p>

      <h3>8. Set IP Manually</h3>
      <p>If the router isn’t assigning an IP address correctly, set a static IP in your network adapter’s settings.</p>

      <h3>9. Check Router and ISP</h3>
      <p>If other devices also have no internet, the issue could be with your router or service provider. Try connecting via Ethernet or contact your ISP.</p>

      <h3>10. Perform a Network Reset</h3>
      <p>In <strong>Settings > Network & Internet > Status</strong>, scroll down and click “Network reset” to reinstall all adapters and restore settings to default.</p>

      <h3>Need More Help?</h3>
      <p>Still stuck? Our tech support team can help you troubleshoot further. <a href="/quick-pc1/contact_us.php">Contact us here</a>.</p>
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message...">
      <button id="send-btn">Send</button>
    </div>
  </div>

  <!-- Chatbot JS -->
  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
