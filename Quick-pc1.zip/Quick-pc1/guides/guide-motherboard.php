<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Diagnose Motherboard Issues</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css" />
  <link rel="stylesheet" href="/quick-pc1/css/guides.css" />
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />
  <style>
    .guide-article p, .guide-article li { text-align: justify; }
  </style>
</head>
<body>

  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo" />
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="guide-article">
      <h2>Diagnose Motherboard Issues</h2>
      <img src="/quick-pc1/images/MB.jpg" alt="Diagnosing Motherboard" />

      <p>The motherboard is the central hub of your PC, connecting all your components. When it malfunctions, it can cause a wide range of issues—from boot failure to random crashes. Here's how to recognize and troubleshoot motherboard problems.</p>

      <h3>Common Symptoms of a Faulty Motherboard</h3>
      <ul>
        <li>PC won’t power on, even with a working power supply</li>
        <li>No display output or beeping error codes</li>
        <li>USB ports, RAM slots, or expansion slots stop functioning</li>
        <li>Random restarts, freezing, or BSOD with no clear cause</li>
        <li>Burn marks, swollen capacitors, or physical damage on the board</li>
      </ul>

      <h3>How to Troubleshoot Motherboard Problems</h3>
      <ol>
        <li><strong>Check the Power:</strong> Ensure the PSU cables are firmly connected to the motherboard (24-pin and 8-pin).</li>
        <li><strong>Listen for Beep Codes:</strong> Use the motherboard speaker to identify BIOS beep codes if the system won't boot.</li>
        <li><strong>Test with Minimal Setup:</strong> Disconnect everything except the CPU, one stick of RAM, and the PSU to isolate the issue.</li>
        <li><strong>Reset the CMOS:</strong> Clear the BIOS settings by removing the CMOS battery or using the jumper method.</li>
        <li><strong>Try Known Working Components:</strong> Swap RAM, GPU, or PSU to rule out those parts.</li>
      </ol>

      <h3>When to Replace Your Motherboard</h3>
      <p>If you've ruled out all other components and the board still fails to POST (power-on self-test), it may be time to replace it. Be sure to choose a replacement that matches your CPU socket and RAM type.</p>

      <h3>Preventing Motherboard Failure</h3>
      <ul>
        <li>Use a surge protector or UPS to prevent electrical damage</li>
        <li>Clean your case regularly to avoid dust buildup</li>
        <li>Ensure proper airflow and cooling, especially near VRMs and chipset</li>
      </ul>

      <h3>Need Expert Advice?</h3>
      <p>Still unsure if your motherboard is the problem? <a href="/quick-pc1/contact_us.php">Reach out to our support team</a> for help with diagnostics and choosing a replacement board.</p>
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>

</body>
</html>
