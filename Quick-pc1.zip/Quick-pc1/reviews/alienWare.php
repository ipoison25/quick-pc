<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>QUICK PC SOLUTIONS - Alienware Aurora Review</title>
  <link rel="stylesheet" href="/quick-pc1/css/style.css" />
  <link rel="stylesheet" href="/quick-pc1/css/reviews.css" />
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo" />
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </header>

  <main>
    <section class="review-article">
      <h2>Alienware Aurora Review</h2>
      <img src="/quick-pc1/images/alienWare.webp" alt="Alienware Aurora" />
      <p>Alienware has long been known for delivering premium gaming PCs that provide impressive performance and eye-catching design. But with the Aurora, the gaming rig balances excellent features with a hefty price tag. In this review, we’ll break down what’s great, what’s not, and why you may—or may not—want to buy one.</p>

      <h3>Specifications</h3>
      <ul>
        <li><strong>CPU:</strong> Intel Core i9 13900F</li>
        <li><strong>GPU:</strong> Nvidia GeForce RTX 4080</li>
        <li><strong>RAM:</strong> 32 GB DDR5-5600</li>
        <li><strong>SSD:</strong> 512 GB (+ 1 TB HDD)</li>
        <li><strong>PSU:</strong> 1000 W</li>
      </ul>

      <h3>Today's Best Deals</h3>
      <p>Get the best prices on Alienware Aurora setups today with special discounts for a limited time. Don't miss out on one of the most powerful gaming rigs available!</p>

      <h3>Reasons to Buy</h3>
      <ul>
        <li>Excellent thermal management and acoustics</li>
        <li>Reliable and high-performance gaming setup</li>
        <li>Easy to upgrade with modular components</li>
        <li>Great ports selection for peripherals</li>
      </ul>

      <h3>Reasons to Avoid</h3>
      <ul>
        <li>Pedestrian design—not as unique as other gaming rigs</li>
        <li>Still uses proprietary barebones components which limit customization</li>
        <li>Small SSD capacity for the price—512 GB is limiting</li>
        <li>Can get ridiculously expensive with configurations</li>
        <li>Restricted CPU performance, no overclocking headroom</li>
        <li>Questionable service and warranty policy</li>
      </ul>

      <h3>Our Favorite Config</h3>
      <p>For a more reasonable price point without sacrificing too much performance, we recommend the following configuration:</p>
      <ul>
        <li><strong>CPU:</strong> Intel Core i7 14700F</li>
        <li><strong>GPU:</strong> Nvidia RTX 4070 Ti Super</li>
        <li><strong>RAM:</strong> 16 GB DDR5-5600</li>
        <li><strong>SSD:</strong> 1 TB</li>
      </ul>

      <h3>Review Summary</h3>
      <p>It's not often that an Alienware gaming rig comes with this much technology for a surprisingly competitive price. The Aurora R16 with the RTX 4070 Ti Super is a solid offering with 16 GB of speedy DDR5 and 1 TB SSD. However, the price remains high, especially with a 512 GB SSD that we think should be larger for the price point. The major downside is Alienware's proprietary hardware—it's not easy to upgrade and can lock you into expensive parts in the future. If you’re willing to accept these trade-offs, you get a powerful, reliable machine.</p>

      <h3>Need More Help?</h3>
      <p>If you have any questions or need further assistance with the Alienware Aurora, feel free to contact us <a href="/quick-pc1/contact_us.php">here</a>.</p>
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <!-- Scripts -->
  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
