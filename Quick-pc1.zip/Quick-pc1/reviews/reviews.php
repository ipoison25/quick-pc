<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>QUICK PC SOLUTIONS - Reviews</title>

  <!-- Link to stylesheets -->
  <link rel="stylesheet" href="/quick-pc1/css/style.css">
  <link rel="stylesheet" href="/quick-pc1/css/reviews.css">
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />

  <!-- Additional meta tags or JS libraries can go here -->
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo"> <!-- Path to your logo -->
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
        <li><button onclick="toggleSearch()">Search</button>

        <!-- Search Form -->
        <form id="search-form" onsubmit="return false;" style="display: none;">
          <input type="text" id="search-query" placeholder="Search..." />
          <button type="submit" onclick="performSearch()">Search</button>
        </form>
      </ul>
    </nav>
  </header>

  <main>
    <section class="hero">
      <h2>Latest Reviews</h2>
      <p>Stay informed with our in-depth reviews on the latest tech products, gadgets, and services.</p>
    </section>

    <section id="latest-reviews" class="reviews-list">
      <article class="review-card">
        <img src="/quick-pc1/images/alienWare.webp" alt="alienWare">
        <div class="review-content">
          <h3><a href="/quick-pc1/reviews/AlienWare.php">Alienware Aurora</a></h3>
          <p>The Alienware Aurora delivers a premium gaming experience with Intel Core i9 and Nvidia RTX 4080. But is it worth the price? Check out our in-depth review and find out!</p>
        </div>
      </article>

      <section id="latest-reviews" class="reviews-list">
  <article class="review-card">
    <img src="/quick-pc1/images/laptops.jpg" alt="Best Gaming Laptops Under $1500">
    <div class="review-content">
      <h3><a href="/quick-pc1/reviews/laptops.php">Best Gaming Laptops Under $1500 (2025 Edition)</a></h3>
      <p>Discover the best gaming laptops of 2025 that offer powerful performance, top-tier GPUs, and great value under $1500. Find out which ones deliver the best gaming experience for your budget!</p>
    </div>
  </article>
</section>


<article class="review-card">
    <img src="/quick-pc1/images/monitor.jpg" alt="Best Budget Monitors for 2025">
    <div class="review-content">
      <h3><a href="/quick-pc1/reviews/monitors.php">Best Budget Monitors for 2025</a></h3>
      <p>Looking for a budget-friendly monitor without compromising performance? Check out our top picks for 2025 that offer great value for both gaming and productivity!</p>
    </div>
  </article>

  <article class="review-card">
    <img src="/quick-pc1/images/apps.png" alt="Best Productivity Apps for 2025">
    <div class="review-content">
      <h3><a href="/quick-pc1/reviews/apps.php">Best Productivity Apps for 2025</a></h3>
      <p>Looking to boost your productivity in 2025? Check out our roundup of the top apps that will help you stay organized and efficient, whether you're working solo or in a team!</p>
    </div>
  </article>

  <article class="review-card">
    <img src="/quick-pc1/images/phones.webp" alt="Best Budget Smartphones of 2025">
    <div class="review-content">
      <h3><a href="/quick-pc1/reviews/phones.php">Best Budget Smartphones of 2025</a></h3>
      <p>Looking for an affordable smartphone under $500 that doesn’t compromise on quality? Check out our top picks for 2025 that offer excellent value for money!</p>
    </div>
  </article>

  <article class="review-card">
  <img src="/quick-pc1/images/external-hard-drive.jpg" alt="Best External Hard Drives for 2025">
  <div class="review-content">
    <h3><a href="/quick-pc1/reviews/best-external-hard-drives-2025.php">Best External Hard Drives for 2025</a></h3>
    <p>Explore the top external hard drives of 2025 that offer great storage, fast speeds, and reliability for all your data storage needs.</p>
  </div>
</article>

<article class="review-card">
  <img src="/quick-pc1/images/wireless-router.jpg" alt="Best Wireless Routers for 2025">
  <div class="review-content">
    <h3><a href="/quick-pc1/reviews/best-wireless-routers-2025.php">Best Wireless Routers for 2025</a></h3>
    <p>Discover the top wireless routers for 2025 that provide fast speeds, better coverage, and advanced features like Wi-Fi 6 and mesh networking.</p>
  </div>
</article>

<article class="review-card">
  <img src="/quick-pc1/images/cloud-storage.jpg" alt="Best Cloud Storage Services for 2025">
  <div class="review-content">
    <h3><a href="/quick-pc1/reviews/best-cloud-storage-2025.php">Best Cloud Storage Services for 2025</a></h3>
    <p>Explore the top cloud storage services of 2025, from Google Drive to iCloud, offering secure, reliable, and fast storage options for all your needs.</p>
  </div>
</article>


    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <!-- Scripts -->
  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/searchF.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
