function logoutUser() {
    window.location.href = "/quick-pc1/Logout.php";
  }