<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>PC Blog - Tech News</title>

  <!-- Link to stylesheets -->
  <link rel="stylesheet" href="/quick-pc1/css/style.css">
  <link rel="stylesheet" href="/quick-pc1/css/news.css">
  <link rel="stylesheet" href="/quick-pc1/css/chatbot.css" />

  
</head>
<body>
  <div class="background-container"></div>

  <header>
    <div class="logo">
      <img src="/quick-pc1/images/logo.webp" alt="Quick PC Solutions Logo"> <!-- Path to your logo -->
    </div>
    <h1>QUICK PC SOLUTIONS</h1>
    <nav>
      <ul>
        <li><a href="/quick-pc1/home.php">Home</a></li>
        <li><a href="/quick-pc1/news/news.php">Tech News</a></li>
        <li><a href="/quick-pc1/reviews/reviews.php">Reviews</a></li>
        <li><a href="/quick-pc1/guides/guides.php">Guides</a></li>
        <li><a href="/quick-pc1/contact_us.php">Contact</a></li>
        <li><a href="/quick-pc1/community.php">Community</a></li>
        <?php if (isset($_SESSION['username'])): ?>
          <li><span style="color:white; padding-right:10px;">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
          <li><button onclick="logoutUser()" style="background:none; border:none; color:white; font-size:16px; cursor:pointer;">Logout</button></li>
        <?php else: ?>
          <li><a href="/quick-pc1/Register.php">Register</a></li>
          <li><a href="/quick-pc1/Login.php">Login</a></li>
        <?php endif; ?>
        <li><button onclick="toggleSearch()">Search</button>

        <!-- Search Form -->
        <form id="search-form" onsubmit="return false;" style="display: none;">
          <input type="text" id="search-query" placeholder="Search..." />
          <button type="submit" onclick="performSearch()">Search</button>
        </form>
      </ul>
    </nav>
  </header>

  <main>
    <section class="hero">
      <h2>Latest Tech News</h2>
      <p>Stay updated with the latest news in the world of technology and computers.</p>
    </section>

    <section id="latest-news" class="news-list">
      <article class="news-card">
        <img src="/quick-pc1/images/New-AI-Breakthrough.avif" alt="AI Technology">
        <div class="news-content">
          <h3><a href="/quick-pc1/news/New-AI-Breakthrough.php">New AI Breakthrough</a></h3>
          <p>Scientists have developed a new AI model that surpasses human-level performance...</p>
        </div>
      </article>

      <article class="news-card">
        <img src="/quick-pc1/images/Quantum.jpg" alt="Quantum Computing">
        <div class="news-content">
          <h3><a href="/quick-pc1/news/Quantum.php">Quantum Computing Advances</a></h3>
          <p>A major leap in quantum computing brings us closer to solving complex problems...</p>
        </div>
      </article>

      <article class="news-card">
        <img src="/quick-pc1/images/Tech-comp.jpg" alt="Tech Mergers">
        <div class="news-content">
          <h3><a href="/quick-pc1/news/Tech-companies.php">Tech Companies Announce Mergers</a></h3>
          <p>Big tech giants are merging to push innovation in artificial intelligence and cloud computing.</p>
        </div>
      </article>

      <article class="news-card">
        <img src="/quick-pc1/images/meta.webp" alt="Meta LlamaCon AI Event">
        <div class="news-content">
          <h3><a href="/quick-pc1/news/meta.php">Meta Announces 'LlamaCon' AI Developer Event</a></h3>
          <p>Meta has unveiled plans for LlamaCon, a new event scheduled for April 29, 2025, to bring together developers and AI enthusiasts. The event will focus on open-source AI tools, specifically Meta’s LLaMA technology.</p>
        </div>
      </article>

      <article class="news-card">
  <img src="/quick-pc1/images/5G.jpg" alt="The Future of 5G">
  <div class="news-content">
    <h3><a href="/quick-pc1/news/future-5G.php">The Future of 5G: Transforming Connectivity</a></h3>
    <p>The global rollout of 5G networks is set to revolutionize industries, providing faster speeds, lower latency, and massive improvements in connectivity. The future of 5G promises new opportunities for businesses and consumers alike, from AI advancements to enhanced mobile experiences.</p>
  </div>
</article>

<article class="news-card">
  <img src="/quick-pc1/images/cloud-comp.png" alt="Cloud Computing and Remote Work">
  <div class="news-content">
    <h3><a href="/quick-pc1/news/cloud-comp.php">Cloud Computing and the Future of Remote Work</a></h3>
    <p>Cloud computing is revolutionizing remote work, providing businesses and employees with flexible, scalable, and cost-effective solutions. Discover how cloud technology is transforming collaboration, data accessibility, and work environments for remote teams.</p>
  </div>
</article>

<article class="news-card">
  <img src="/quick-pc1/images/cyber.jpeg" alt="Cybersecurity in the Age of Ransomware">
  <div class="news-content">
    <h3><a href="/quick-pc1/news/Cybersecurity.php">Cybersecurity in the Age of Ransomware: Protecting Your Data</a></h3>
    <p>Ransomware attacks are on the rise, posing a significant threat to businesses and individuals. Learn how to protect your data, prevent ransomware attacks, and respond effectively if you become a victim.</p>
  </div>
</article>

<article class="news-card">
  <img src="/quick-pc1/images/IoT.jpg" alt="The Internet of Things (IoT)">
  <div class="news-content">
    <h3><a href="/quick-pc1/news/iot-smarter-world.php">The Internet of Things (IoT): Connecting Everything for a Smarter World</a></h3>
    <p>The Internet of Things (IoT) is transforming how we live and work, connecting everyday devices to the internet to create smarter homes, cities, and industries. Discover how IoT is shaping a more efficient, data-driven world.</p>
  </div>
</article>

      
    </section>
  </main>

  <!-- Chatbot -->
  <div class="chat-toggle" id="chat-toggle">ChatBot</div>
  <div class="chatbot-container" id="chatbot">
    <div class="chat-header">
      Chat with us 
      <span class="minimize-icon" id="minimize-chat">–</span>
    </div>
    <div class="chat-body" id="chat-body"></div>
    <div class="chat-input">
      <input type="text" id="user-input" placeholder="Type a message..." />
      <button id="send-btn">Send</button>
    </div>
  </div>

  <!-- Scripts -->
  <script src="/quick-pc1/chatbot.js"></script>
  <script src="/quick-pc1/searchF.js"></script>
  <script src="/quick-pc1/Logout.js"></script>

  <footer>
    <p>&copy; 2025 Quick PC Solutions</p>
  </footer>
</body>
</html>
